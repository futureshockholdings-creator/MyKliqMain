# MyKliq – iOS Xcode Build

## Step 1 — Install JS dependencies (on your Mac)
```
npm install
```
Run this in the MyKliq-mobile/ folder. Takes ~1 minute.

## Step 2 — Install CocoaPods
```
cd ios
pod install
```
This generates MyKliq.xcworkspace. Takes 2-5 minutes.

## Step 3 — Open in Xcode
Open MyKliq.xcworkspace (NOT MyKliq.xcodeproj):
```
open MyKliq.xcworkspace
```

## Step 4 — Archive & Submit
1. Set destination to "Any iOS Device (arm64)"
2. Signing & Capabilities → Team: futureshockholdings (7S3JDKMQRG)
3. Product → Archive
4. Distribute App → App Store Connect → Upload
